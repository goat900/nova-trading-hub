# Nova Trade Hub — Complete Front-end Project

A responsive two-part website starter inspired by the broad layout pattern of DB Traders: a public landing page plus a signed-in trading workspace. This is an original Nova Trade Hub implementation; it does not copy DB Traders source code, logos, text or proprietary assets.

## Project files
- `index.html` — landing page, workspace shell, auth demo modal and tool views
- `styles.css` — responsive dark navy / gold interface
- `app.js` — navigation, demo interactions and tool configuration previews
- `_redirects` — Cloudflare Pages SPA fallback
- `wrangler.toml` — optional Cloudflare Pages project metadata

## Pages and tools
### Public website
- Hero / calls to action
- Synthetic market ticker (labelled demo)
- Features, workflow and risk disclosure
- Login and create-account modal

### Workspace
- Overview dashboard and sample chart
- Free Bots, Premium Bots, Bot Builder
- Auto Trader, Manual Trader
- Digit Scanner, Copy Trader, Bulk Trader
- SpeedBot, DeepScanner, Charts, Performance

## Run locally
Open `index.html` in a browser or use VS Code Live Server.

## Deploy to Cloudflare Pages
1. Extract this ZIP.
2. Create a Cloudflare Pages project.
3. Upload the extracted project folder or connect its GitHub repository.
4. Framework preset: None.
5. Build command: leave blank.
6. Build output directory: `/` (project root).
7. Deploy.

No build step or package installation is required.

## Production integration still required
This is a front-end starter only. Login and registration are demo UI, not real authentication. The displayed chart, ticker, balance, activity and digit frequencies are illustrative sample data. No real Deriv connection, live feed, signal prediction, bot execution, copy trading, deposit or withdrawal functionality is implemented.

Before production:
- Implement secure account authentication and database persistence.
- Register a Deriv application and configure its exact allowed redirect URI.
- Implement OAuth authorization-code flow with PKCE and secure server-side token handling.
- Add authorized Deriv WebSocket market data and validate symbols/contracts.
- Build server-side contract proposal/execution with user confirmation, strict stake/session limits, loss limits, kill switch and audit logs.
- Add real transaction history and calculate performance only from verified records.
- Perform security, privacy and applicable legal/compliance review.

Never put app secrets or access tokens in this repository. Start with a virtual account and read-only scopes. Do not present sample metrics as real performance or imply guaranteed returns.
